package lecture_3;

public class Loops_1 {
public static void main(String[] args) {
	int i=1; // initialize 
	int sum =0;
	while(i<=5) { // COndition
		int ans = i*2;
		System.out.println("2*"+i+"="+ans);
//		sum = sum +i;
//		System.out.println(sum);
		i=i+1;// Updation
	}
//	System.out.println(sum);

}
}
