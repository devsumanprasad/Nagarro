package lecture_3;

public class Simple_int {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int p = 1000;
		int r = 10;
		int t = 10;
		int ans = p*r*t/100;
		System.out.println("Simple Int : "+ans);
	}

}
