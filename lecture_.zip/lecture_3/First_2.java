package lecture_3;

public class First_2 {

	public static void main(String[] args) {
		
	}

}
