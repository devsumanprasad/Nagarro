package lecture_3;

public class Report_card {
	public static void main(String[] args) {
		int marks = 60;
		if(marks >=60) {
			System.out.println("Pass with marks " + marks);
		}
//		else {
//			System.out.println("Fail with marks "+ marks);
//		}
		if(marks<100) {
			System.out.println("Fail with marks "+ marks);
		}
	}

}
