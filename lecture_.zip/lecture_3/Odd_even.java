package lecture_3;

public class Odd_even {
public static void main(String[] args) {
	int n  =11;
	System.out.println("Hi");
	if (n%2==0) {
		System.out.println("Even");
	}
	else {
		System.out.println("Odd");
	}
	System.out.println("Bye");
}
}
