package lecture_5;

public class Pattern00 {
	public static void main(String[] args) {
//		System.out.println("****");
//		int n =5;
//		for(int cst =1;cst<=n;cst++) {
//			
//			System.out.print("* ");
//		}
		int nsp = 0;
		for(int csp =1;csp <=nsp;csp = csp+1) {
//			System.out.print(csp +" _ ");
			System.out.println(csp);
		}
		
		
//		if(true) {
//			int x=10;
//		}
//		
//		System.out.println(x);
	}
}
